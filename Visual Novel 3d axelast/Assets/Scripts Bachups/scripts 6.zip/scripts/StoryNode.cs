using UnityEngine;
using System.Collections.Generic; // Required for List<>

[System.Serializable]
public class ConditionalClickTransition
{
    [Tooltip("Optional description for Inspector clarity.")]
    public string description;
    [Tooltip("Number of clicks within the current chapter (specifically for Chapter 4 logic).")]
    public int requiredChapterClicks;
    public StoryNode targetNode;
}

[System.Serializable]
public class PenaltyClickTransition
{
    [Tooltip("Optional description for Inspector clarity.")]
    public string description;
    [Tooltip("Total number of penalty clicks accumulated (for Chapter 6+ logic).")]
    public int requiredTotalPenaltyClicks;
    public StoryNode targetNode;
}

public class StoryNode : MonoBehaviour
{
    [Tooltip("The chapter this node belongs to.")]
    public int chapter = 1;
    public string nodeText;
    public Sprite background;
    public AudioClip backgroundSound; 
    public StoryNode nextOnSew;
    public StoryNode nextOnClick;

    [Header("Chapter 4 Conditional Transitions")]
    [Tooltip("Transitions based on click count within Chapter 4.")]
    public List<ConditionalClickTransition> chapter4ClickTransitions;

    [Header("Chapter 6+ Penalty Transitions")]
    [Tooltip("Transitions based on total penalty clicks (from Chapter 6 onwards).")]
    public List<PenaltyClickTransition> penaltyClickTransitions;
}
