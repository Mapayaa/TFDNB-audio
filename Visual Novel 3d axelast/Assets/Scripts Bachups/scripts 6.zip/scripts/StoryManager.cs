using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StoryManager : MonoBehaviour
{
    public Image backgroundImage;
    public TextMeshProUGUI textBox;

    public StoryNode currentNode;

    public AudioClip sewingSoundClip; // Sound to play when space is held
    public AudioSource sewingAudioSource; // AudioSource for the sewing sound
    public AudioSource backgroundAudioSource; // AudioSource for node-specific background sounds
    public AudioSource wordAudioSource; // AudioSource for typing sound
    public AudioClip typingSoundClip; // Single sound to loop/play during text reveal

    [Header("Per-Letter Text Reveal Settings")]
    public float letterReveal_MinDelay = 0.02f;
    public float letterReveal_MaxDelay = 0.1f;
    public float letterReveal_HighlightDuration = 1.0f;
    public float letterReveal_SizeMultiplier = 1.2f; // e.g., 1.2 for 120%
    public Color letterReveal_HighlightColor = new Color(0.85f, 0.85f, 0.85f, 1f); // A light grey

    private Coroutine displayTextCoroutine; // To manage the text display coroutine
    private System.Collections.Generic.List<RevealedChar> activeTextCharacters;
    private System.Text.StringBuilder textBuilder = new System.Text.StringBuilder();
    private float baseFontSize; // To store the original font size of the textBox

    [Header("Chapter & Game State")]
    public StoryNode chapter6StartNode; // Assign in Inspector: the first node of Chapter 6
    public Image passOutScreenImage; // Assign in Inspector: UI Image for Chapter 5 pass-out
    public float chapter5PassOutScreenDuration = 3.0f;
    
    private int currentChapter = 1;
    private int clicksInCurrentChapter = 0;
    private int totalPenaltyClicks = 0;
    private StoryNode previousStoryNode; // For "sew back" logic and general previous node tracking
    private bool inputDisabled = false; // To disable input during sequences like pass-out
    private bool awaitingSewBack = false; // True if the player just made a penalty click and should sew back

    [Header("Sewing Mechanic State")]
    private bool isSewing = false; // True if space is currently held down
    private bool sewingSoundActiveForThisHold; // True if sound should be playing for current sewing action
    private Vector2 startPos; // Still used for initial press, but logic changes
    private Vector2 previousMousePosition; // For accumulating distance
    private float accumulatedSewingDistance; // Accumulates total path length
    public float requiredDistance = 500f;

    private struct RevealedChar
    {
        public char character;
        public float appearanceTime;
        public bool isVisible;
        public bool isSpaceOrNewline; // To handle spaces/newlines correctly without highlighting
    }

    void Awake()
    {
        if (passOutScreenImage != null)
        {
            passOutScreenImage.gameObject.SetActive(false); // Ensure pass-out screen is hidden initially
        }

        // Setup Sewing AudioSource
        if (sewingAudioSource == null)
        {
            Debug.LogWarning("StoryManager: sewingAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            sewingAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure properties are set even if it was assigned in Inspector
        sewingAudioSource.loop = true;
        sewingAudioSource.playOnAwake = false;

        // Setup Background AudioSource
        if (backgroundAudioSource == null)
        {
            Debug.LogWarning("StoryManager: backgroundAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            backgroundAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure it's a different component if auto-added and sewingAudioSource was also auto-added
        if (backgroundAudioSource == sewingAudioSource && sewingAudioSource.gameObject.GetComponents<AudioSource>().Length < 2) {
             // This case implies both were null and AddComponent was called for sewingAudioSource.
             // If backgroundAudioSource points to the same one, we need a new one.
             Debug.LogWarning("StoryManager: backgroundAudioSource was pointing to the same component as sewingAudioSource. Adding a distinct AudioSource for background.");
             backgroundAudioSource = gameObject.AddComponent<AudioSource>();
        }
        backgroundAudioSource.loop = true;
        backgroundAudioSource.playOnAwake = false;

        // Setup Word AudioSource
        if (wordAudioSource == null)
        {
            Debug.LogWarning("StoryManager: wordAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            wordAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure it's a different component if auto-added
        if ((wordAudioSource == sewingAudioSource || wordAudioSource == backgroundAudioSource) && sewingAudioSource.gameObject.GetComponents<AudioSource>().Length < 3) {
            Debug.LogWarning("StoryManager: wordAudioSource was pointing to the same component as another AudioSource. Adding a distinct AudioSource for words.");
            wordAudioSource = gameObject.AddComponent<AudioSource>();
        }
        wordAudioSource.loop = true; // For typing sound loop
        wordAudioSource.playOnAwake = false;

        // Final check if any are still null (shouldn't happen with AddComponent)
        if (sewingAudioSource == null) Debug.LogError("CRITICAL: sewingAudioSource is STILL NULL after Awake setup!");
        if (backgroundAudioSource == null) Debug.LogError("CRITICAL: backgroundAudioSource is STILL NULL after Awake setup!");
        if (wordAudioSource == null) Debug.LogError("CRITICAL: wordAudioSource is STILL NULL after Awake setup!");

        if (textBox != null)
        {
            baseFontSize = textBox.fontSize;
        }
        else
        {
            Debug.LogError("StoryManager: textBox is not assigned in Awake. Base font size cannot be determined for letter animations.");
            // Potentially set a default baseFontSize or handle this more gracefully.
            baseFontSize = 36; // Default fallback if textBox is not set early
        }
    }

    void Start()
    {
        ShowNode(currentNode);
    }

    void Update()
    {
        if (inputDisabled) return; // Disable input during sequences like pass-out

        // Handle sewing input and sound
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (sewingAudioSource == null)
            {
                Debug.LogError("StoryManager: sewingAudioSource is not assigned in the Inspector or couldn't be found/added in Awake().");
            }
            else if (sewingSoundClip == null)
            {
                Debug.LogError("StoryManager: sewingSoundClip is not assigned in the Inspector.");
            }
            // Sound starting logic moved to a helper or inline
            // No longer checking isPlaying here, as sewingSoundActiveForThisHold controls intent
            else
            {
                // Start playing sound only if it's intended for this new hold action
                if (sewingSoundActiveForThisHold && !sewingAudioSource.isPlaying)
                {
                    Debug.Log("StoryManager: Starting sewing sound.");
                    sewingAudioSource.clip = sewingSoundClip;
                    sewingAudioSource.Play();
                }
            }
            startPos = Input.mousePosition; 
            previousMousePosition = Input.mousePosition;
            // accumulatedSewingDistance is reset here
            isSewing = true; 
            sewingSoundActiveForThisHold = true; // Sound should play at the start of a new hold
            accumulatedSewingDistance = 0f; // Reset for the new sewing action
        }
        else if (Input.GetKeyUp(KeyCode.Space)) 
        {
            if (sewingAudioSource != null && sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Stopping sewing sound on space release.");
                sewingAudioSource.Stop();
            }
            isSewing = false;
            sewingSoundActiveForThisHold = false;
            accumulatedSewingDistance = 0f; // Reset accumulated distance when space is released
        }

        if (isSewing)
        {
            // If sound should be active but isn't playing (e.g., after a reset but space still held), start it.
            // This handles the case where distance is met, sound stops, counter resets, and user continues to hold space.
            if (sewingSoundActiveForThisHold && sewingAudioSource != null && sewingSoundClip != null && !sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Restarting sewing sound during continuous hold.");
                sewingAudioSource.clip = sewingSoundClip;
                sewingAudioSource.Play();
            }
            
            Vector2 currentMousePosition = Input.mousePosition;
            float deltaDistance = (currentMousePosition - previousMousePosition).magnitude;
            accumulatedSewingDistance += deltaDistance;
            previousMousePosition = currentMousePosition;

            Debug.Log("Accumulated Sewing Distance: " + accumulatedSewingDistance);

            if (accumulatedSewingDistance >= requiredDistance)
            {
                Debug.Log("StoryManager: Required distance met.");
                Next("sew");
                
                if (sewingAudioSource != null && sewingAudioSource.isPlaying)
                {
                    Debug.Log("StoryManager: Stopping sewing sound because required distance met.");
                    sewingAudioSource.Stop();
                }
                sewingSoundActiveForThisHold = false; // Stop sound for the rest of this "segment"

                // Reset for next potential trigger in the same hold, sound will restart if user keeps moving.
                accumulatedSewingDistance = 0f; 
                // If space is still held, the next Update will set sewingSoundActiveForThisHold = true
                // if we want sound to restart for the *next* segment immediately.
                // As per new feedback, sound should NOT restart until space is released and pressed again.
                // So, sewingSoundActiveForThisHold remains false for the rest of this hold.
            }
        }
        else // if !isSewing (e.g. space was released, or sewing action completed)
        {
            // Ensure sound is stopped if isSewing became false for any reason other than KeyUp
            if (sewingAudioSource != null && sewingAudioSource.isPlaying && !sewingSoundActiveForThisHold) {
                sewingAudioSource.Stop();
            }
        }

        // Handle click input
        if (Input.GetMouseButtonDown(0))
        {
            Next("click");
        }
    }

    void ShowNode(StoryNode node)
    {
        if (node == null)
        {
            Debug.LogError("ShowNode: Target node is null. Cannot proceed.");
            // Potentially handle this more gracefully, e.g., by returning to a main menu or a safe node.
            inputDisabled = true; // Prevent further input if story is broken
            return;
        }

        // --- Chapter Transition Logic ---
        if (node.chapter != currentChapter)
        {
            Debug.Log($"Transitioning from Chapter {currentChapter} to Chapter {node.chapter}");
            currentChapter = node.chapter;
            clicksInCurrentChapter = 0; // Reset chapter-specific click count
            awaitingSewBack = false; // Reset sew back state on any chapter change

            if (currentChapter == 5)
            {
                // If this node is specifically the trigger for pass-out, or if any node in Ch5 starts it.
                // For now, assume any entry into Ch5 starts pass-out.
                // If Ch5 has introductory nodes before pass-out, this logic needs refinement.
                // Let's assume for now that a node with chapter=5 is the pass-out trigger.
                StartCoroutine(PassOutAndProceedCoroutine());
                return; // PassOutAndProceedCoroutine will handle the next ShowNode call
            }
        }
        
        // Stop any existing text display coroutine and associated sound
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
        }

        // Set current node *after* chapter transition logic but *before* text animation
        // previousStoryNode is set in Next() method before calling ShowNode for non-sew-back actions
        currentNode = node; 

        InitializeTextForAnimation(currentNode.nodeText); 
        textBox.text = ""; 
        displayTextCoroutine = StartCoroutine(AnimateTextCharacterByCharacter(currentNode));

        if (backgroundImage != null) // Check if backgroundImage itself is assigned
        {
            if (currentNode.background != null)
            {
                backgroundImage.sprite = currentNode.background;
                backgroundImage.gameObject.SetActive(true);
            }
            else
            {
                // Optionally hide background image if node has no sprite, or leave as is
                // backgroundImage.gameObject.SetActive(false); 
            }
        }
        else
        {
            Debug.LogWarning("ShowNode: backgroundImage UI element is not assigned in the Inspector.");
        }


        if (backgroundAudioSource != null)
        {
            if (backgroundAudioSource.isPlaying)
            {
                backgroundAudioSource.Stop();
            }
            if (currentNode.backgroundSound != null)
            {
                backgroundAudioSource.clip = currentNode.backgroundSound;
                backgroundAudioSource.Play();
            }
        }
    }

    void Next(string method)
    {
        if (inputDisabled) return; // Should be caught by Update, but as a safeguard

        StoryNode nextNode = null;
        bool isSewBackAction = false;

        // Stop current text animation and show full text before processing Next()
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
            if (currentNode != null && textBox != null) // Ensure currentNode and textBox are valid
            {
                textBox.text = currentNode.nodeText; // Display full text instantly
            }
        }

        if (currentNode == null) {
            Debug.LogError("Next: currentNode is null. Cannot determine next action.");
            return;
        }

        if (method == "click")
        {
            clicksInCurrentChapter++;
            if (currentChapter >= 6)
            {
                totalPenaltyClicks++;
                Debug.Log($"Total Penalty Clicks: {totalPenaltyClicks}");
            }
            Debug.Log($"Clicks in Chapter {currentChapter}: {clicksInCurrentChapter}");

            previousStoryNode = currentNode; // Set for potential sew back or general tracking
            awaitingSewBack = false; // Reset, will be set true if a penalty click transition occurs

            switch (currentChapter)
            {
                case 1:
                case 2:
                case 3:
                    nextNode = currentNode.nextOnClick;
                    break;
                case 4:
                    if (currentNode.chapter4ClickTransitions != null)
                    {
                        foreach (var transition in currentNode.chapter4ClickTransitions)
                        {
                            if (transition.requiredChapterClicks == clicksInCurrentChapter)
                            {
                                nextNode = transition.targetNode;
                                break;
                            }
                        }
                    }
                    // If no match, nextNode remains null (click does nothing, must sew)
                    break;
                case 5: // Input should be disabled, but handle defensively
                    Debug.LogWarning("Click received during Chapter 5 (Pass-out). Should be disabled.");
                    break;
                default: // Chapter 6 and onwards
                    if (currentNode.penaltyClickTransitions != null)
                    {
                        foreach (var transition in currentNode.penaltyClickTransitions)
                        {
                            if (transition.requiredTotalPenaltyClicks == totalPenaltyClicks)
                            {
                                nextNode = transition.targetNode;
                                awaitingSewBack = true; // This click leads to a state where sewing goes back
                                break;
                            }
                        }
                    }
                    // If no match, nextNode remains null
                    break;
            }
        }
        else if (method == "sew")
        {
            // previousStoryNode is NOT updated here, as sewing doesn't usually set up a "sew back from where you sewed to"
            switch (currentChapter)
            {
                case 1:
                case 2:
                case 3:
                case 4: // Standard sew for chapter 4
                    nextNode = currentNode.nextOnSew;
                    awaitingSewBack = false; // Sewing clears any pending sew-back state
                    break;
                case 5: // Input should be disabled
                    Debug.LogWarning("Sew action received during Chapter 5 (Pass-out). Should be disabled.");
                    break;
                default: // Chapter 6 and onwards
                    if (awaitingSewBack && previousStoryNode != null)
                    {
                        nextNode = previousStoryNode;
                        isSewBackAction = true; // To prevent previousStoryNode from being overwritten in ShowNode by itself
                        awaitingSewBack = false; // Sew back action completed
                        // previousStoryNode = null; // Clear previousStoryNode after using it for sew back
                    }
                    else
                    {
                        nextNode = currentNode.nextOnSew;
                        awaitingSewBack = false; // Normal sew clears any pending sew-back state
                    }
                    break;
            }
        }

        if (nextNode != null)
        {
            // If it's not a sew back action, the current node (soon to be old) becomes the previous one.
            // This was already handled for "click". For "sew", if it's a forward sew:
            if (method == "sew" && !isSewBackAction) {
                 previousStoryNode = currentNode;
            }
            ShowNode(nextNode);
            if (isSewBackAction) {
                previousStoryNode = null; // After successfully sewing back, clear previous node to prevent immediate re-sew-back on next sew.
            }
        }
        else
        {
            Debug.Log($"No valid next node for action '{method}' from node '{currentNode.name}' in chapter {currentChapter}. Clicks this chapter: {clicksInCurrentChapter}, Total penalty: {totalPenaltyClicks}. AwaitingSewBack: {awaitingSewBack}");
        }
    }

    System.Collections.IEnumerator PassOutAndProceedCoroutine()
    {
        Debug.Log("Chapter 5: Starting pass-out sequence.");
        inputDisabled = true;
        awaitingSewBack = false; // Clear any pending sew-back state

        // Stop any ongoing text animation and sound
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            displayTextCoroutine = null;
        }
        if (wordAudioSource != null && wordAudioSource.isPlaying)
        {
            wordAudioSource.Stop();
        }
        textBox.text = ""; // Clear text

        if (passOutScreenImage != null)
        {
            passOutScreenImage.color = Color.black; // Or use a fade
            passOutScreenImage.gameObject.SetActive(true);
        }
        else
        {
            Debug.LogWarning("PassOutScreenImage not assigned in Inspector. Cannot show black screen.");
        }

        yield return new WaitForSeconds(chapter5PassOutScreenDuration);

        if (passOutScreenImage != null)
        {
            passOutScreenImage.gameObject.SetActive(false); // Or fade out
        }

        if (chapter6StartNode != null)
        {
            Debug.Log("Chapter 5: Pass-out finished. Proceeding to Chapter 6.");
            // currentChapter will be updated by ShowNode via chapter6StartNode.chapter
            // clicksInCurrentChapter will be reset by ShowNode
            ShowNode(chapter6StartNode);
        }
        else
        {
            Debug.LogError("Chapter 6 Start Node is not assigned in StoryManager! Cannot proceed from Chapter 5.");
            // Story is stuck here.
        }
        inputDisabled = false;
    }

    void InitializeTextForAnimation(string textToAnimate)
    {
        if (activeTextCharacters == null)
        {
            activeTextCharacters = new System.Collections.Generic.List<RevealedChar>();
        }
        activeTextCharacters.Clear();

        if (string.IsNullOrEmpty(textToAnimate)) return;

        foreach (char c in textToAnimate)
        {
            activeTextCharacters.Add(new RevealedChar
            {
                character = c,
                appearanceTime = float.MaxValue, // Not appeared yet
                isVisible = false,
                isSpaceOrNewline = (c == ' ' || c == '\n' || c == '\r')
            });
        }
    }

    void UpdateDisplayedText()
    {
        if (textBox == null || activeTextCharacters == null) return;
        if (baseFontSize <= 0 && textBox != null) baseFontSize = textBox.fontSize; // Attempt to get base font size again if missed in Awake

        textBuilder.Clear();
        float currentTime = Time.time;
        string highlightColorHex = ColorUtility.ToHtmlStringRGB(letterReveal_HighlightColor);
        // TMP uses font units for size tags, not percentages directly in the way CSS might.
        // <size=X> sets absolute font units. <size=+X> or <size=X%> are relative.
        // Let's use percentage for clarity with multiplier.
        string sizeTagStart = $"<size={letterReveal_SizeMultiplier * 100f}%>";
        const string sizeTagEnd = "</size>";
        string colorTagStart = $"<color=#{highlightColorHex}>";
        const string colorTagEnd = "</color>";

        for (int i = 0; i < activeTextCharacters.Count; i++)
        {
            RevealedChar charInfo = activeTextCharacters[i];
            if (!charInfo.isVisible)
            {
                // To maintain layout for partially revealed text, we might need to add invisible chars
                // or ensure TextMeshPro handles this well. For now, break if not visible.
                // A better way is to build up to the last visible char.
                break; 
            }

            if (charInfo.isSpaceOrNewline)
            {
                textBuilder.Append(charInfo.character);
            }
            else if (currentTime < charInfo.appearanceTime + letterReveal_HighlightDuration)
            {
                // Apply highlight
                textBuilder.Append(sizeTagStart);
                textBuilder.Append(colorTagStart);
                textBuilder.Append(charInfo.character);
                textBuilder.Append(colorTagEnd);
                textBuilder.Append(sizeTagEnd);
            }
            else
            {
                // Normal character
                textBuilder.Append(charInfo.character);
            }
        }
        textBox.text = textBuilder.ToString();
    }


    System.Collections.IEnumerator AnimateTextCharacterByCharacter(StoryNode node)
    {
        if (textBox == null)
        {
            Debug.LogError("AnimateTextCharacterByCharacter: textBox is null.");
            displayTextCoroutine = null;
            yield break;
        }
        
        if (activeTextCharacters == null || activeTextCharacters.Count == 0)
        {
             // This case means InitializeTextForAnimation wasn't called or node text was empty.
             // ShowNode should call InitializeTextForAnimation.
            if (node != null && !string.IsNullOrEmpty(node.nodeText)) InitializeTextForAnimation(node.nodeText);
            else {
                textBox.text = ""; // Ensure text is cleared
                if (wordAudioSource != null && wordAudioSource.isPlaying) wordAudioSource.Stop();
                displayTextCoroutine = null;
                yield break;
            }
        }

        if (wordAudioSource != null && typingSoundClip != null && !wordAudioSource.isPlaying)
        {
            wordAudioSource.clip = typingSoundClip;
            wordAudioSource.loop = true;
            wordAudioSource.Play();
        }

        // This loop reveals characters one by one
        for (int i = 0; i < activeTextCharacters.Count; i++)
        {
            RevealedChar charInfo = activeTextCharacters[i];
            charInfo.isVisible = true;
            charInfo.appearanceTime = Time.time;
            activeTextCharacters[i] = charInfo; // Update struct in list

            UpdateDisplayedText(); // Update the visible text box content

            if (!charInfo.isSpaceOrNewline) // Don't delay for spaces/newlines themselves, but content after them
            {
                 yield return new WaitForSeconds(Random.Range(letterReveal_MinDelay, letterReveal_MaxDelay));
            } else if (charInfo.character == '\n') { // Optional: slightly longer pause for newlines
                 yield return new WaitForSeconds(Random.Range(letterReveal_MinDelay, letterReveal_MaxDelay) * 2f);
            }
        }

        // This loop keeps updating the text for highlight fade-outs after all chars are visible
        float animationEndTime = Time.time + letterReveal_HighlightDuration; 
        while (Time.time < animationEndTime)
        {
            UpdateDisplayedText();
            // Check if all characters have returned to normal state to potentially end early
            bool allNormal = true;
            float currentTime = Time.time;
            for(int i=0; i < activeTextCharacters.Count; ++i) {
                if(activeTextCharacters[i].isVisible && !activeTextCharacters[i].isSpaceOrNewline && 
                   currentTime < activeTextCharacters[i].appearanceTime + letterReveal_HighlightDuration) {
                    allNormal = false;
                    break;
                }
            }
            if(allNormal) break;

            yield return null; // Wait for next frame
        }
        
        // Ensure final text is clean without tags if UpdateDisplayedText doesn't run one last time
        textBox.text = node.nodeText; 

        if (wordAudioSource != null && wordAudioSource.isPlaying)
        {
            wordAudioSource.Stop();
        }
        displayTextCoroutine = null; // Mark as finished
    }
}
