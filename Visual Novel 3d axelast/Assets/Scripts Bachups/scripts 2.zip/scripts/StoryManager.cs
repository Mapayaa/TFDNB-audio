using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StoryManager : MonoBehaviour
{
    public Image backgroundImage;
    public TextMeshProUGUI textBox;

    public StoryNode currentNode;

    public AudioClip sewingSoundClip; // Sound to play when space is held
    public AudioSource sewingAudioSource; // AudioSource for the sewing sound
    public AudioSource backgroundAudioSource; // AudioSource for node-specific background sounds

    private bool isSewing = false;
    private Vector2 startPos; // Still used for initial press, but logic changes
    private Vector2 previousMousePosition; // For accumulating distance
    private float accumulatedSewingDistance; // Accumulates total path length
    public float requiredDistance = 100f;

    void Awake() // Changed from Start to ensure AudioSources are ready
    {
        // Attempt to get existing AudioSources or add them if they don't exist
        AudioSource[] sources = GetComponents<AudioSource>();
        if (sources.Length >= 2)
        {
            sewingAudioSource = sources[0];
            backgroundAudioSource = sources[1];
        }
        else if (sources.Length == 1)
        {
            sewingAudioSource = sources[0];
            backgroundAudioSource = gameObject.AddComponent<AudioSource>();
            Debug.LogWarning("StoryManager: Only one AudioSource found. Added a second one for background audio.");
        }
        else
        {
            sewingAudioSource = gameObject.AddComponent<AudioSource>();
            backgroundAudioSource = gameObject.AddComponent<AudioSource>();
            Debug.LogWarning("StoryManager: No AudioSources found. Added two AudioSources.");
        }

        if (sewingAudioSource != null)
        {
            sewingAudioSource.loop = true; // Sewing sound should loop
            sewingAudioSource.playOnAwake = false;
        }
        if (backgroundAudioSource != null)
        {
            backgroundAudioSource.loop = true; // Background sound should loop
            backgroundAudioSource.playOnAwake = false;
        }
    }

    void Start()
    {
        ShowNode(currentNode);
    }

    void Update()
    {
        // Handle sewing input and sound
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (sewingAudioSource != null && sewingSoundClip != null && !sewingAudioSource.isPlaying)
            {
                sewingAudioSource.clip = sewingSoundClip;
                sewingAudioSource.Play();
            }
            startPos = Input.mousePosition; // Keep for potential other uses or if original intent was mixed
            previousMousePosition = Input.mousePosition; // Initialize for accumulation
            accumulatedSewingDistance = 0f; // Reset accumulated distance
            isSewing = true;
        }
        else if (Input.GetKeyUp(KeyCode.Space)) // Use else if to avoid processing KeyUp in the same frame as KeyDown
        {
            if (sewingAudioSource != null && sewingAudioSource.isPlaying)
            {
                sewingAudioSource.Stop();
            }
            isSewing = false;
        }

        if (isSewing)
        {
            Vector2 currentMousePosition = Input.mousePosition;
            float deltaDistance = (currentMousePosition - previousMousePosition).magnitude;
            accumulatedSewingDistance += deltaDistance;
            previousMousePosition = currentMousePosition;

            // For debugging, you might want to see this value:
            // Debug.Log("Accumulated Sewing Distance: " + accumulatedSewingDistance);

            if (accumulatedSewingDistance >= requiredDistance)
            {
                Next("sew");
                // Reset accumulated distance after triggering "sew" to require new accumulation for next trigger.
                // Or, if "sew" should only trigger once per spacebar hold, manage isSewing state.
                // For now, let's reset it so it can be triggered again if space is still held and mouse moves further.
                accumulatedSewingDistance = 0f; 
            }
        }

        // Handle click input
        if (Input.GetMouseButtonDown(0))
        {
            Next("click");
        }
    }

    void ShowNode(StoryNode node)
    {
        if (node == null)
        {
            Debug.LogError("ShowNode: node is null. Make sure currentNode is assigned in the Inspector.");
            if (textBox != null)
            {
                textBox.text = "Error: Story node not found.";
            }
            return;
        }

        if (textBox == null)
        {
            Debug.LogError("ShowNode: textBox is null. Make sure the TextMeshProUGUI component is assigned in the Inspector.");
            return;
        }
        textBox.text = node.nodeText;

        if (backgroundImage == null)
        {
            Debug.LogWarning("ShowNode: backgroundImage is null. Background will not be updated.");
        }
        else
        {
            backgroundImage.sprite = node.background;
        }

        // Handle node-specific background sound
        if (backgroundAudioSource != null)
        {
            if (backgroundAudioSource.isPlaying)
            {
                backgroundAudioSource.Stop();
            }
            if (node.backgroundSound != null)
            {
                backgroundAudioSource.clip = node.backgroundSound;
                backgroundAudioSource.Play();
            }
        }
        
        currentNode = node;
    }

    void Next(string method)
    {
        if (method == "sew" && currentNode.nextOnSew != null)
            ShowNode(currentNode.nextOnSew);
        else if (method == "click" && currentNode.nextOnClick != null)
            ShowNode(currentNode.nextOnClick);
    }
}
