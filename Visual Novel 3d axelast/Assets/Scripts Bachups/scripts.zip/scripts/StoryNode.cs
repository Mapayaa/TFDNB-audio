using UnityEngine;

public class StoryNode : MonoBehaviour
{
    public string nodeText;
    public Sprite background;
    public StoryNode nextOnSew;
    public StoryNode nextOnClick;
}
