using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StoryManager : MonoBehaviour
{
    public Image backgroundImage;
    public TextMeshProUGUI textBox;

    public StoryNode currentNode;

    private bool isSewing = false;
    private Vector2 startPos;
    public float requiredDistance = 100f;

    void Start()
    {
        ShowNode(currentNode);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            startPos = Input.mousePosition;
            isSewing = true;
        }

        if (Input.GetKeyUp(KeyCode.Space))
        {
            isSewing = false;
        }

        if (isSewing)
        {
            float distance = (Input.mousePosition - (Vector3)startPos).magnitude;
            if (distance > requiredDistance)
            {
                Next("sew");
            }
        }

        if (Input.GetMouseButtonDown(0))
        {
            Next("click");
        }
    }

    void ShowNode(StoryNode node)
    {
        textBox.text = node.nodeText;
        backgroundImage.sprite = node.background;
        currentNode = node;
    }

    void Next(string method)
    {
        if (method == "sew" && currentNode.nextOnSew != null)
            ShowNode(currentNode.nextOnSew);
        else if (method == "click" && currentNode.nextOnClick != null)
            ShowNode(currentNode.nextOnClick);
    }
}
