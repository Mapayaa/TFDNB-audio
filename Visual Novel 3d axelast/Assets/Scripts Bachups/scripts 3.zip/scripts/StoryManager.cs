using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StoryManager : MonoBehaviour
{
    public Image backgroundImage;
    public TextMeshProUGUI textBox;

    public StoryNode currentNode;

    public AudioClip sewingSoundClip; // Sound to play when space is held
    public AudioSource sewingAudioSource; // AudioSource for the sewing sound
    public AudioSource backgroundAudioSource; // AudioSource for node-specific background sounds
    public AudioSource wordAudioSource; // AudioSource for word-by-word text sounds
    public AudioClip typingSoundClip; // Single sound to loop/play during text reveal
    public float delayBetweenWords = 0.15f; // Delay for typewriter effect

    private Coroutine displayTextCoroutine; // To manage the text display coroutine
    private bool isSewing = false; // True if space is currently held down
    private bool sewingSoundActiveForThisHold; // True if sound should be playing for current sewing action
    private Vector2 startPos; // Still used for initial press, but logic changes
    private Vector2 previousMousePosition; // For accumulating distance
    private float accumulatedSewingDistance; // Accumulates total path length
    public float requiredDistance = 500f;

    void Awake()
    {
        // Setup Sewing AudioSource
        if (sewingAudioSource == null)
        {
            Debug.LogWarning("StoryManager: sewingAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            sewingAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure properties are set even if it was assigned in Inspector
        sewingAudioSource.loop = true;
        sewingAudioSource.playOnAwake = false;

        // Setup Background AudioSource
        if (backgroundAudioSource == null)
        {
            Debug.LogWarning("StoryManager: backgroundAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            backgroundAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure it's a different component if auto-added and sewingAudioSource was also auto-added
        if (backgroundAudioSource == sewingAudioSource && sewingAudioSource.gameObject.GetComponents<AudioSource>().Length < 2) {
             // This case implies both were null and AddComponent was called for sewingAudioSource.
             // If backgroundAudioSource points to the same one, we need a new one.
             Debug.LogWarning("StoryManager: backgroundAudioSource was pointing to the same component as sewingAudioSource. Adding a distinct AudioSource for background.");
             backgroundAudioSource = gameObject.AddComponent<AudioSource>();
        }
        backgroundAudioSource.loop = true;
        backgroundAudioSource.playOnAwake = false;

        // Setup Word AudioSource
        if (wordAudioSource == null)
        {
            Debug.LogWarning("StoryManager: wordAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            wordAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure it's a different component if auto-added
        if ((wordAudioSource == sewingAudioSource || wordAudioSource == backgroundAudioSource) && sewingAudioSource.gameObject.GetComponents<AudioSource>().Length < 3) {
            Debug.LogWarning("StoryManager: wordAudioSource was pointing to the same component as another AudioSource. Adding a distinct AudioSource for words.");
            wordAudioSource = gameObject.AddComponent<AudioSource>();
        }
        wordAudioSource.loop = true; // For typing sound loop
        wordAudioSource.playOnAwake = false;

        // Final check if any are still null (shouldn't happen with AddComponent)
        if (sewingAudioSource == null) Debug.LogError("CRITICAL: sewingAudioSource is STILL NULL after Awake setup!");
        if (backgroundAudioSource == null) Debug.LogError("CRITICAL: backgroundAudioSource is STILL NULL after Awake setup!");
        if (wordAudioSource == null) Debug.LogError("CRITICAL: wordAudioSource is STILL NULL after Awake setup!");
    }

    void Start()
    {
        ShowNode(currentNode);
    }

    void Update()
    {
        // Handle sewing input and sound
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (sewingAudioSource == null)
            {
                Debug.LogError("StoryManager: sewingAudioSource is not assigned in the Inspector or couldn't be found/added in Awake().");
            }
            else if (sewingSoundClip == null)
            {
                Debug.LogError("StoryManager: sewingSoundClip is not assigned in the Inspector.");
            }
            // Sound starting logic moved to a helper or inline
            // No longer checking isPlaying here, as sewingSoundActiveForThisHold controls intent
            else
            {
                // Start playing sound only if it's intended for this new hold action
                if (sewingSoundActiveForThisHold && !sewingAudioSource.isPlaying)
                {
                    Debug.Log("StoryManager: Starting sewing sound.");
                    sewingAudioSource.clip = sewingSoundClip;
                    sewingAudioSource.Play();
                }
            }
            startPos = Input.mousePosition; 
            previousMousePosition = Input.mousePosition;
            // accumulatedSewingDistance is reset here
            isSewing = true; 
            sewingSoundActiveForThisHold = true; // Sound should play at the start of a new hold
            accumulatedSewingDistance = 0f; // Reset for the new sewing action
        }
        else if (Input.GetKeyUp(KeyCode.Space)) 
        {
            if (sewingAudioSource != null && sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Stopping sewing sound on space release.");
                sewingAudioSource.Stop();
            }
            isSewing = false;
            sewingSoundActiveForThisHold = false;
            accumulatedSewingDistance = 0f; // Reset accumulated distance when space is released
        }

        if (isSewing)
        {
            // If sound should be active but isn't playing (e.g., after a reset but space still held), start it.
            // This handles the case where distance is met, sound stops, counter resets, and user continues to hold space.
            if (sewingSoundActiveForThisHold && sewingAudioSource != null && sewingSoundClip != null && !sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Restarting sewing sound during continuous hold.");
                sewingAudioSource.clip = sewingSoundClip;
                sewingAudioSource.Play();
            }
            
            Vector2 currentMousePosition = Input.mousePosition;
            float deltaDistance = (currentMousePosition - previousMousePosition).magnitude;
            accumulatedSewingDistance += deltaDistance;
            previousMousePosition = currentMousePosition;

            Debug.Log("Accumulated Sewing Distance: " + accumulatedSewingDistance);

            if (accumulatedSewingDistance >= requiredDistance)
            {
                Debug.Log("StoryManager: Required distance met.");
                Next("sew");
                
                if (sewingAudioSource != null && sewingAudioSource.isPlaying)
                {
                    Debug.Log("StoryManager: Stopping sewing sound because required distance met.");
                    sewingAudioSource.Stop();
                }
                sewingSoundActiveForThisHold = false; // Stop sound for the rest of this "segment"

                // Reset for next potential trigger in the same hold, sound will restart if user keeps moving.
                accumulatedSewingDistance = 0f; 
                // If space is still held, the next Update will set sewingSoundActiveForThisHold = true
                // if we want sound to restart for the *next* segment immediately.
                // As per new feedback, sound should NOT restart until space is released and pressed again.
                // So, sewingSoundActiveForThisHold remains false for the rest of this hold.
            }
        }
        else // if !isSewing (e.g. space was released, or sewing action completed)
        {
            // Ensure sound is stopped if isSewing became false for any reason other than KeyUp
            if (sewingAudioSource != null && sewingAudioSource.isPlaying && !sewingSoundActiveForThisHold) {
                sewingAudioSource.Stop();
            }
        }

        // Handle click input
        if (Input.GetMouseButtonDown(0))
        {
            Next("click");
        }
    }

    void ShowNode(StoryNode node)
    {
        if (node == null)
        {
            Debug.LogError("ShowNode: node is null. Make sure currentNode is assigned in the Inspector.");
            if (textBox != null)
            {
                textBox.text = "Error: Story node not found.";
            }
            return;
        }

        if (textBox == null)
        {
            Debug.LogError("ShowNode: textBox is null. Make sure the TextMeshProUGUI component is assigned in the Inspector.");
            return;
        }
        // Stop any existing text display coroutine and associated sound
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
        }
        textBox.text = ""; // Clear text box before starting new text
        displayTextCoroutine = StartCoroutine(DisplayNodeTextWordByWord(node));

        if (backgroundImage == null)
        {
            Debug.LogWarning("ShowNode: backgroundImage is null. Background will not be updated.");
        }
        else
        {
            backgroundImage.sprite = node.background;
        }

        // Handle node-specific background sound
        if (backgroundAudioSource != null)
        {
            if (backgroundAudioSource.isPlaying)
            {
                backgroundAudioSource.Stop();
            }
            if (node.backgroundSound != null)
            {
                backgroundAudioSource.clip = node.backgroundSound;
                backgroundAudioSource.Play();
            }
        }
        
        currentNode = node;
    }

    void Next(string method)
    {
        // It's good practice to stop text coroutine before moving to next node,
        // ShowNode already does this, so direct call here might be redundant
        // but ensures it if Next() logic changes.
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
            // If ShowNode is called, it will clear the text. If not (e.g. end of story),
            // ensure the full text of the current node is displayed instantly.
            if (currentNode != null && textBox != null) textBox.text = currentNode.nodeText;
        }

        if (method == "sew" && currentNode.nextOnSew != null)
            ShowNode(currentNode.nextOnSew);
        else if (method == "click" && currentNode.nextOnClick != null)
            ShowNode(currentNode.nextOnClick);
    }

    System.Collections.IEnumerator DisplayNodeTextWordByWord(StoryNode node)
    {
        if (node == null || string.IsNullOrEmpty(node.nodeText))
        {
            if (textBox != null) textBox.text = "";
            if (wordAudioSource != null && wordAudioSource.isPlaying) wordAudioSource.Stop();
            displayTextCoroutine = null;
            yield break;
        }

        textBox.text = ""; // Ensure it's clear

        if (wordAudioSource != null && typingSoundClip != null)
        {
            wordAudioSource.clip = typingSoundClip;
            wordAudioSource.loop = true;
            wordAudioSource.Play();
        }

        string[] words = node.nodeText.Split(' ');
        for (int i = 0; i < words.Length; i++)
        {
            textBox.text += words[i];
            if (i < words.Length - 1) // Add space if not the last word
            {
                textBox.text += " ";
            }
            // Sound is already looping, no need to play per word
            yield return new WaitForSeconds(delayBetweenWords);
        }

        if (wordAudioSource != null && wordAudioSource.isPlaying)
        {
            wordAudioSource.Stop();
        }
        displayTextCoroutine = null; // Mark as finished
    }
}
