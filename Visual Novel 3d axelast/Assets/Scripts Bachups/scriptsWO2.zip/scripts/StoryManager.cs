using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic; // For List<>

// Define this class here or in its own file if preferred
[System.Serializable]
public class GlobalPenaltyNodeMapping
{
    [Tooltip("Optional description for Inspector clarity.")]
    public string description;
    [Tooltip("Total penalty clicks required to trigger this mapping.")]
    public int requiredTotalPenaltyClicks;
    [Tooltip("The 'strafnode' (penalty node) to go to.")]
    public StoryNode targetStrafNode;
    [Tooltip("If true, after sewing back from targetStrafNode, advance to the next node in the Chapter 6+ Sew Nodes list.")]
    public bool advanceSewListAfterReturningFromThisStraf;
}

public class StoryManager : MonoBehaviour
{
    public Image backgroundImage;
    public TextMeshProUGUI textBox;

    public StoryNode currentNode;

    public AudioClip sewingSoundClip; // Sound to play when space is held
    public AudioSource sewingAudioSource; // AudioSource for the sewing sound
    public AudioSource backgroundAudioSource; // AudioSource for node-specific background sounds
    public AudioSource wordAudioSource; // AudioSource for typing sound
    public AudioClip typingSoundClip; // Single sound to loop/play during text reveal

    [Header("Per-Letter Text Reveal Settings")]
    public float letterReveal_MinDelay = 0.02f;
    public float letterReveal_MaxDelay = 0.1f;
    public float letterReveal_HighlightDuration = 1.0f;
    public float letterReveal_SizeMultiplier = 1.2f; // e.g., 1.2 for 120%
    public Color letterReveal_HighlightColor = new Color(0.85f, 0.85f, 0.85f, 1f); // A light grey

    private Coroutine displayTextCoroutine; // To manage the text display coroutine
    private System.Collections.Generic.List<RevealedChar> activeTextCharacters;
    private System.Text.StringBuilder textBuilder = new System.Text.StringBuilder();
    private float baseFontSize; // To store the original font size of the textBox

    [Header("Chapter & Game State")]
    public StoryNode chapter6StartNode; // Assign in Inspector: the first node of Chapter 6
    public Image passOutScreenImage; // Assign in Inspector: UI Image for Chapter 5 pass-out
    public float chapter5PassOutScreenDuration = 3.0f;
    [Tooltip("Centrally defined list of nodes for the main 'sew' progression in Chapter 6+.")]
    public List<StoryNode> chapter6PlusSewNodes;
    [Tooltip("Centrally defined mappings from total penalty clicks to specific penalty nodes for Chapter 6+. Must be sorted by Required Total Penalty Clicks.")]
    public List<GlobalPenaltyNodeMapping> chapter6PlusPenaltyMappings;
    
    private int currentChapter = 1;
    private int clicksInCurrentChapter = 0;
    private int totalPenaltyClicks = 0;
    private StoryNode previousStoryNode; // For "sew back" logic
    private bool inputDisabled = false; // To disable input during sequences like pass-out
    private bool awaitingSewBack = false; // True if the player just made a penalty click and should sew back
    private int currentSewNodeIndex = 0; // Index for chapter6PlusSewNodes
    private bool storedAdvanceSewListFlag = false; // Stores the advance flag from the penalty mapping

    [Header("Sewing Mechanic State")]
    public float requiredDistance = 50f; // Adjusted for GetAxis input, needs tuning
    [Tooltip("Max ratio of horizontal to vertical movement allowed for a sewing streak (e.g., 0.5 means horizontal delta can be 0.5 * vertical delta). Strict vertical is 0.")]
    public float maxHorizontalToVerticalRatio = 0.5f;
    [Tooltip("Minimum positive Y movement in a frame to be considered for ratio check, to avoid division by small numbers issues or extreme ratios with tiny Y movements.")]
    public float minYDeltaForRatioCheck = 0.01f; 
    [Tooltip("Minimum horizontal movement when Y movement is zero, to be considered as breaking the streak.")]
    public float minXDeltaWhenYIsZero = 0.01f; 
    public float mouseSensitivityY_Sewing = 10f; 
    public float mouseSensitivityX_Sewing = 10f; 

    private bool isSewing = false; 
    private bool sewingSoundActiveForThisHold; 
    private float accumulatedSewingDistance; 


    private struct RevealedChar
    {
        public char character;
        public float appearanceTime;
        public bool isVisible;
        public bool isSpaceOrNewline; 
    }

    void Awake()
    {
        if (passOutScreenImage != null)
        {
            passOutScreenImage.gameObject.SetActive(false); 
        }

        if (sewingAudioSource == null) { Debug.LogWarning("StoryManager: sewingAudioSource was not assigned..."); sewingAudioSource = gameObject.AddComponent<AudioSource>(); }
        sewingAudioSource.loop = true; sewingAudioSource.playOnAwake = false;
        if (backgroundAudioSource == null) { Debug.LogWarning("StoryManager: backgroundAudioSource was not assigned..."); backgroundAudioSource = gameObject.AddComponent<AudioSource>(); }
        if (backgroundAudioSource == sewingAudioSource && GetComponents<AudioSource>().Length < 2) { Debug.LogWarning("StoryManager: backgroundAudioSource was pointing to sewingAudioSource..."); backgroundAudioSource = gameObject.AddComponent<AudioSource>(); }
        backgroundAudioSource.loop = true; backgroundAudioSource.playOnAwake = false;
        if (wordAudioSource == null) { Debug.LogWarning("StoryManager: wordAudioSource was not assigned..."); wordAudioSource = gameObject.AddComponent<AudioSource>(); }
        if ((wordAudioSource == sewingAudioSource || wordAudioSource == backgroundAudioSource) && GetComponents<AudioSource>().Length < 3) { Debug.LogWarning("StoryManager: wordAudioSource was pointing to another AudioSource..."); wordAudioSource = gameObject.AddComponent<AudioSource>(); }
        wordAudioSource.loop = true; wordAudioSource.playOnAwake = false;
        if (sewingAudioSource == null) Debug.LogError("CRITICAL: sewingAudioSource is STILL NULL!");
        if (backgroundAudioSource == null) Debug.LogError("CRITICAL: backgroundAudioSource is STILL NULL!");
        if (wordAudioSource == null) Debug.LogError("CRITICAL: wordAudioSource is STILL NULL!");

        if (textBox != null) { baseFontSize = textBox.fontSize; }
        else { Debug.LogError("StoryManager: textBox is not assigned in Awake."); baseFontSize = 36; }
    }

    void Start()
    {
        if (currentNode == null) {
            Debug.LogError("StoryManager: CurrentNode (starting node) is not assigned in the Inspector!");
            inputDisabled = true; 
            return;
        }
        ShowNode(currentNode);
    }

    void Update()
    {
        if (inputDisabled) return; 

        if (isSewing && Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (sewingAudioSource != null && sewingAudioSource.isPlaying) sewingAudioSource.Stop();
            isSewing = false;
            sewingSoundActiveForThisHold = false;
            accumulatedSewingDistance = 0f;
            Debug.Log("Sewing action cancelled by Escape key.");
        }

        if (!isSewing && Input.GetKeyDown(KeyCode.Space)) 
        {
            if (sewingAudioSource == null) Debug.LogError("StoryManager: sewingAudioSource is not assigned.");
            else if (sewingSoundClip == null) Debug.LogError("StoryManager: sewingSoundClip is not assigned.");
            
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            isSewing = true; 
            sewingSoundActiveForThisHold = true; 
            accumulatedSewingDistance = 0f; 
            
            if (sewingSoundActiveForThisHold && sewingAudioSource != null && sewingSoundClip != null && !sewingAudioSource.isPlaying)
            {
                 Debug.Log("StoryManager: Starting sewing sound on KeyDown.");
                 sewingAudioSource.clip = sewingSoundClip;
                 sewingAudioSource.Play();
            }
        }
        else if (isSewing && Input.GetKeyUp(KeyCode.Space)) 
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (sewingAudioSource != null && sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Stopping sewing sound on space release.");
                sewingAudioSource.Stop();
            }
            isSewing = false;
            sewingSoundActiveForThisHold = false;
            accumulatedSewingDistance = 0f; 
        }

        if (isSewing)
        {
            float rawDeltaY = Input.GetAxis("Mouse Y");
            float rawDeltaX = Input.GetAxis("Mouse X");
            float effectiveDeltaY = rawDeltaY * mouseSensitivityY_Sewing;
            float effectiveDeltaX = rawDeltaX * mouseSensitivityX_Sewing;
            
            bool movementIsValidForStreak = true;

            if (effectiveDeltaY < 0) { 
                movementIsValidForStreak = false;
            } else if (effectiveDeltaY > minYDeltaForRatioCheck) { 
                if (Mathf.Abs(effectiveDeltaX) > (effectiveDeltaY * maxHorizontalToVerticalRatio)) {
                    movementIsValidForStreak = false;
                }
            } else if (Mathf.Approximately(effectiveDeltaY, 0) && Mathf.Abs(effectiveDeltaX) > (minXDeltaWhenYIsZero * mouseSensitivityX_Sewing)) { 
                 movementIsValidForStreak = false;
            }

            if (movementIsValidForStreak && effectiveDeltaY > 0) { 
                accumulatedSewingDistance += effectiveDeltaY;
            } else if (!movementIsValidForStreak && (Mathf.Abs(rawDeltaX) > 0.001f || Mathf.Abs(rawDeltaY) > 0.001f) ) { 
                accumulatedSewingDistance = 0f;
            }
            
            if (accumulatedSewingDistance >= requiredDistance)
            {
                Debug.Log($"StoryManager: Required distance met ({accumulatedSewingDistance:F2} >= {requiredDistance}). Triggering 'sew'.");
                
                if (sewingAudioSource != null && sewingAudioSource.isPlaying) {
                    Debug.Log("StoryManager: Stopping sewing sound because required distance met.");
                    sewingAudioSource.Stop();
                }
                sewingSoundActiveForThisHold = false; 
                
                Next("sew"); 
                
                accumulatedSewingDistance = 0f; 
            }
        }
        
        if (Input.GetMouseButtonDown(0))
        {
            if (Cursor.lockState == CursorLockMode.Locked) {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                if (isSewing) { 
                    isSewing = false;
                    sewingSoundActiveForThisHold = false;
                    if (sewingAudioSource != null && sewingAudioSource.isPlaying) sewingAudioSource.Stop();
                    accumulatedSewingDistance = 0f;
                    Debug.Log("Sewing action interrupted by click.");
                }
            }
            Next("click");
        }
    }

    void ShowNode(StoryNode node)
    {
        if (node == null)
        {
            Debug.LogError("ShowNode: Target node is null. Cannot proceed.");
            inputDisabled = true; 
            return;
        }

        if (node.chapter != currentChapter)
        {
            Debug.Log($"Transitioning from Chapter {currentChapter} to Chapter {node.chapter}");
            currentChapter = node.chapter;
            clicksInCurrentChapter = 0; 
            awaitingSewBack = false; 

            if (currentChapter == 5)
            {
                StartCoroutine(PassOutAndProceedCoroutine());
                return; 
            }
            else if (currentChapter == 6 && (previousStoryNode == null || previousStoryNode.chapter < 6)) 
            {
                if (chapter6PlusSewNodes != null && chapter6PlusSewNodes.Count > 0 && chapter6StartNode != null)
                {
                    currentSewNodeIndex = chapter6PlusSewNodes.IndexOf(chapter6StartNode);
                    if (currentSewNodeIndex == -1) {
                        Debug.LogWarning($"Chapter 6 start node '{chapter6StartNode.name}' not found in chapter6PlusSewNodes list. Defaulting sew index to 0.");
                        currentSewNodeIndex = 0; 
                    } else {
                        Debug.Log($"Entered Chapter 6. Initialized currentSewNodeIndex to {currentSewNodeIndex} for node {chapter6StartNode.name}.");
                    }
                } else {
                     currentSewNodeIndex = 0; 
                }
            }
        }
        
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
        }

        currentNode = node; 

        if (currentChapter >= 6 && chapter6PlusSewNodes != null && chapter6PlusSewNodes.Contains(currentNode))
        {
            currentSewNodeIndex = chapter6PlusSewNodes.IndexOf(currentNode);
        }

        InitializeTextForAnimation(currentNode.nodeText); 
        if(textBox != null) textBox.text = ""; 
        displayTextCoroutine = StartCoroutine(AnimateTextCharacterByCharacter(currentNode));

        if (backgroundImage != null) 
        {
            if (currentNode.background != null)
            {
                backgroundImage.sprite = currentNode.background;
                backgroundImage.gameObject.SetActive(true);
            }
            else { /* backgroundImage.gameObject.SetActive(false); */ }
        }
        else
        {
            Debug.LogWarning("ShowNode: backgroundImage UI element is not assigned in the Inspector.");
        }

        if (backgroundAudioSource != null)
        {
            if (backgroundAudioSource.isPlaying)
            {
                backgroundAudioSource.Stop();
            }
            if (currentNode.backgroundSound != null)
            {
                backgroundAudioSource.clip = currentNode.backgroundSound;
                backgroundAudioSource.Play();
            }
        }
    }

    void Next(string method)
    {
        if (inputDisabled) return; 

        StoryNode nextNode = null;
        bool isSewBackAction = false;

        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
            if (currentNode != null && textBox != null) 
            {
                textBox.text = currentNode.nodeText; 
            }
        }

        if (currentNode == null) {
            Debug.LogError("Next: currentNode is null. Cannot determine next action.");
            return;
        }

        if (method == "click")
        {
            clicksInCurrentChapter++;
            if (currentChapter >= 6)
            {
                totalPenaltyClicks++;
                Debug.Log($"Total Penalty Clicks: {totalPenaltyClicks}");
            }
            // Debug.Log($"Clicks in Chapter {currentChapter}: {clicksInCurrentChapter}");

            previousStoryNode = currentNode; 
            awaitingSewBack = false; 
            storedAdvanceSewListFlag = false;

            switch (currentChapter)
            {
                case 1: case 2: case 3:
                    nextNode = currentNode.nextOnClick;
                    break;
                case 4: 
                    if (currentNode.chapter4ClickTransitions != null && currentNode.chapter4ClickTransitions.Count > 0)
                    {
                        StoryNode matchedNode = null;
                        foreach (var transition in currentNode.chapter4ClickTransitions)
                        {
                            if (clicksInCurrentChapter == transition.requiredChapterClicks)
                            {
                                matchedNode = transition.targetNode; break;
                            }
                        }
                        if (matchedNode != null) nextNode = matchedNode;
                        else
                        {
                            var lastTransition = currentNode.chapter4ClickTransitions[currentNode.chapter4ClickTransitions.Count - 1];
                            if (clicksInCurrentChapter > lastTransition.requiredChapterClicks)
                            {
                                nextNode = lastTransition.targetNode;
                                Debug.Log($"Chapter 4: clicksInCurrentChapter ({clicksInCurrentChapter}) exceeded max defined ({lastTransition.requiredChapterClicks}). Repeating last transition to node: {(nextNode != null ? nextNode.name : "NULL")}");
                            }
                        }
                    }
                    break;
                case 5: 
                    Debug.LogWarning("Click received during Chapter 5 (Pass-out). Input should be disabled.");
                    break;
                default: // Chapter 6 and onwards
                    if (chapter6PlusPenaltyMappings != null && chapter6PlusPenaltyMappings.Count > 0)
                    {
                        GlobalPenaltyNodeMapping chosenMapping = null;
                        foreach (var mapping in chapter6PlusPenaltyMappings)
                        {
                            if (totalPenaltyClicks == mapping.requiredTotalPenaltyClicks)
                            {
                                chosenMapping = mapping; 
                                break;
                            }
                        }
                        if (chosenMapping != null)
                        {
                            nextNode = chosenMapping.targetStrafNode;
                            storedAdvanceSewListFlag = chosenMapping.advanceSewListAfterReturningFromThisStraf;
                            awaitingSewBack = true;
                            Debug.Log($"H6+ Click: Exact penalty map found. From {(previousStoryNode != null ? previousStoryNode.name : "NULL")} to {(nextNode != null ? nextNode.name : "NULL")}. awaitingSewBack=true, storedAdvanceFlag={storedAdvanceSewListFlag}");
                        }
                        else
                        {
                            var lastMapping = chapter6PlusPenaltyMappings[chapter6PlusPenaltyMappings.Count - 1];
                            if (totalPenaltyClicks > lastMapping.requiredTotalPenaltyClicks)
                            {
                                nextNode = lastMapping.targetStrafNode;
                                storedAdvanceSewListFlag = lastMapping.advanceSewListAfterReturningFromThisStraf;
                                awaitingSewBack = true;
                                Debug.Log($"H6+ Click: totalPenaltyClicks ({totalPenaltyClicks}) exceeded max defined ({lastMapping.requiredTotalPenaltyClicks}). From {(previousStoryNode != null ? previousStoryNode.name : "NULL")} repeating last penalty mapping to node: {(nextNode != null ? nextNode.name : "NULL")}. awaitingSewBack=true, storedAdvanceFlag={storedAdvanceSewListFlag}");
                            }
                        }
                    }
                    break;
            }
        }
        else if (method == "sew")
        {
            sewingSoundActiveForThisHold = false; 

            switch (currentChapter)
            {
                case 1: case 2: case 3: case 4:
                    nextNode = currentNode.nextOnSew;
                    awaitingSewBack = false; 
                    break;
                case 5:
                    Debug.LogWarning("Sew action received during Chapter 5 (Pass-out). Input should be disabled.");
                    break;
                default: // Chapter 6 and onwards
                    Debug.Log($"H6+ Sew: CurrentNode={(currentNode != null ? currentNode.name : "NULL")}, awaitingSewBack={this.awaitingSewBack}, previousStoryNode={(previousStoryNode == null ? "NULL" : previousStoryNode.name)}, storedAdvanceFlag={storedAdvanceSewListFlag}");
                    if (this.awaitingSewBack && previousStoryNode != null) 
                    {
                        Debug.Log($"H6+ Sew: Attempting sew-back. Initial nextNode will be {previousStoryNode.name}. storedAdvanceFlag is {storedAdvanceSewListFlag}.");
                        nextNode = previousStoryNode;
                        isSewBackAction = true;
                        this.awaitingSewBack = false; 

                        if (storedAdvanceSewListFlag)
                        {
                            int prevNodeIndexInSewList = -1;
                            if (chapter6PlusSewNodes != null && previousStoryNode != null) 
                            {
                                prevNodeIndexInSewList = chapter6PlusSewNodes.IndexOf(previousStoryNode);
                            }

                            if (prevNodeIndexInSewList != -1 && prevNodeIndexInSewList < chapter6PlusSewNodes.Count - 1)
                            {
                                currentSewNodeIndex = prevNodeIndexInSewList + 1;
                                nextNode = chapter6PlusSewNodes[currentSewNodeIndex]; 
                                Debug.Log($"H6+ Sew: Sew-back with advance flag. Advanced in Sew List to: {(nextNode != null ? nextNode.name : "NULL")} at index {currentSewNodeIndex}");
                            }
                            else 
                            { 
                                Debug.LogWarning($"H6+ Sew: Tried to advance sew list on return, but previous node '{(previousStoryNode != null ? previousStoryNode.name : "NULL")}' not in sew list, or at end of list. Staying at {(nextNode != null ? nextNode.name : "NULL")}.");
                            }
                            storedAdvanceSewListFlag = false; 
                        }
                        Debug.Log($"H6+ Sew: Final nextNode after sew-back logic is {(nextNode == null ? "NULL" : nextNode.name)}.");
                    }
                    else 
                    {
                        Debug.Log($"H6+ Sew: Performing normal sew progression from {(currentNode != null ? currentNode.name : "NULL")}. currentSewNodeIndex before logic: {currentSewNodeIndex}. awaitingSewBack was {this.awaitingSewBack}.");
                        if (chapter6PlusSewNodes != null && chapter6PlusSewNodes.Count > 0)
                        {
                            if (currentNode != null && chapter6PlusSewNodes.Contains(currentNode)) { 
                                currentSewNodeIndex = chapter6PlusSewNodes.IndexOf(currentNode);
                            } 

                            if (currentSewNodeIndex < chapter6PlusSewNodes.Count - 1)
                            {
                                currentSewNodeIndex++;
                                nextNode = chapter6PlusSewNodes[currentSewNodeIndex];
                            }
                            else
                            {
                                Debug.Log("H6+ Sew: End of Chapter 6+ sew nodes list reached. Falling back to currentNode.nextOnSew.");
                                if(currentNode != null) nextNode = currentNode.nextOnSew; 
                                if(nextNode == null) Debug.Log("H6+ Sew: No further sew path defined at end of central list or on node's nextOnSew.");
                            }
                        }
                        else {
                             Debug.LogWarning("H6+ Sew: Chapter6PlusSewNodes list is empty or null. Falling back to currentNode.nextOnSew.");
                             if(currentNode != null) nextNode = currentNode.nextOnSew; 
                        }
                        this.awaitingSewBack = false; 
                        Debug.Log($"H6+ Sew: Normal sew progression. nextNode is {(nextNode == null ? "NULL" : nextNode.name)}. New currentSewNodeIndex: {currentSewNodeIndex}.");
                    }
                    break;
            }
        }

        if (nextNode != null)
        {
            if (method == "click" || (method == "sew" && !isSewBackAction)) {
                 if(method == "sew" && currentNode != null) this.previousStoryNode = currentNode;
            }
            ShowNode(nextNode);
            if (isSewBackAction) {
                this.previousStoryNode = null; 
            }
        }
        else
        {
            Debug.Log($"No valid next node for action '{method}' from node '{(currentNode != null ? currentNode.name : "NULL")}' in chapter {currentChapter}. Clicks this chapter: {clicksInCurrentChapter}, Total penalty: {totalPenaltyClicks}. AwaitingSewBack: {awaitingSewBack}");
        }
    }

    System.Collections.IEnumerator PassOutAndProceedCoroutine()
    {
        Debug.Log("Chapter 5: Starting pass-out sequence.");
        inputDisabled = true;
        awaitingSewBack = false; 

        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            displayTextCoroutine = null;
        }
        if (wordAudioSource != null && wordAudioSource.isPlaying)
        {
            wordAudioSource.Stop();
        }
        if(textBox != null) textBox.text = ""; 

        if (passOutScreenImage != null)
        {
            passOutScreenImage.color = Color.black; 
            passOutScreenImage.gameObject.SetActive(true);
        }
        else
        {
            Debug.LogWarning("PassOutScreenImage not assigned in Inspector. Cannot show black screen.");
        }

        yield return new WaitForSeconds(chapter5PassOutScreenDuration);

        if (passOutScreenImage != null)
        {
            passOutScreenImage.gameObject.SetActive(false); 
        }

        if (chapter6StartNode != null)
        {
            Debug.Log("Chapter 5: Pass-out finished. Proceeding to Chapter 6.");
            ShowNode(chapter6StartNode);
        }
        else
        {
            Debug.LogError("Chapter 6 Start Node is not assigned in StoryManager! Cannot proceed from Chapter 5.");
        }
        
        isSewing = false;
        sewingSoundActiveForThisHold = false;
        if (sewingAudioSource != null && sewingAudioSource.isPlaying)
        {
            sewingAudioSource.Stop();
            Debug.Log("StoryManager: Stopped sewing sound after pass-out, just in case.");
        }
        accumulatedSewingDistance = 0f; 

        inputDisabled = false;
        Debug.Log("Chapter 5: Pass-out finished, input re-enabled, input states reset.");
    }

    void InitializeTextForAnimation(string textToAnimate)
    {
        if (activeTextCharacters == null)
        {
            activeTextCharacters = new System.Collections.Generic.List<RevealedChar>();
        }
        activeTextCharacters.Clear();

        if (string.IsNullOrEmpty(textToAnimate)) return;

        foreach (char c in textToAnimate)
        {
            activeTextCharacters.Add(new RevealedChar
            {
                character = c,
                appearanceTime = float.MaxValue, 
                isVisible = false,
                isSpaceOrNewline = (c == ' ' || c == '\n' || c == '\r')
            });
        }
    }

    void UpdateDisplayedText()
    {
        if (textBox == null || activeTextCharacters == null) return;
        if (baseFontSize <= 0 && textBox != null) baseFontSize = textBox.fontSize; 

        textBuilder.Clear();
        float currentTime = Time.time;
        string highlightColorHex = ColorUtility.ToHtmlStringRGB(letterReveal_HighlightColor);
        string sizeTagStart = $"<size={letterReveal_SizeMultiplier * 100f}%>";
        const string sizeTagEnd = "</size>";
        string colorTagStart = $"<color=#{highlightColorHex}>";
        const string colorTagEnd = "</color>";

        for (int i = 0; i < activeTextCharacters.Count; i++)
        {
            RevealedChar charInfo = activeTextCharacters[i];
            if (!charInfo.isVisible)
            {
                break; 
            }

            if (charInfo.isSpaceOrNewline)
            {
                textBuilder.Append(charInfo.character);
            }
            else if (currentTime < charInfo.appearanceTime + letterReveal_HighlightDuration)
            {
                textBuilder.Append(sizeTagStart);
                textBuilder.Append(colorTagStart);
                textBuilder.Append(charInfo.character);
                textBuilder.Append(colorTagEnd);
                textBuilder.Append(sizeTagEnd);
            }
            else
            {
                textBuilder.Append(charInfo.character);
            }
        }
        textBox.text = textBuilder.ToString();
    }

    System.Collections.IEnumerator AnimateTextCharacterByCharacter(StoryNode node)
    {
        if (textBox == null)
        {
            Debug.LogError("AnimateTextCharacterByCharacter: textBox is null.");
            displayTextCoroutine = null;
            yield break;
        }
        
        if (activeTextCharacters == null || activeTextCharacters.Count == 0)
        {
            if (node != null && !string.IsNullOrEmpty(node.nodeText)) InitializeTextForAnimation(node.nodeText);
            else {
                if(textBox != null) textBox.text = ""; 
                if (wordAudioSource != null && wordAudioSource.isPlaying) wordAudioSource.Stop();
                displayTextCoroutine = null;
                yield break;
            }
        }

        if (wordAudioSource != null && typingSoundClip != null && !wordAudioSource.isPlaying)
        {
            wordAudioSource.clip = typingSoundClip;
            wordAudioSource.loop = true;
            wordAudioSource.Play();
        }

        for (int i = 0; i < activeTextCharacters.Count; i++)
        {
            RevealedChar charInfo = activeTextCharacters[i];
            charInfo.isVisible = true;
            charInfo.appearanceTime = Time.time;
            activeTextCharacters[i] = charInfo; 

            UpdateDisplayedText(); 

            if (!charInfo.isSpaceOrNewline) 
            {
                 yield return new WaitForSeconds(Random.Range(letterReveal_MinDelay, letterReveal_MaxDelay));
            } else if (charInfo.character == '\n') { 
                 yield return new WaitForSeconds(Random.Range(letterReveal_MinDelay, letterReveal_MaxDelay) * 2f);
            }
        }

        float animationEndTime = Time.time + letterReveal_HighlightDuration; 
        while (Time.time < animationEndTime)
        {
            UpdateDisplayedText();
            bool allNormal = true;
            float currentTime = Time.time;
            for(int i=0; i < activeTextCharacters.Count; ++i) {
                if(activeTextCharacters[i].isVisible && !activeTextCharacters[i].isSpaceOrNewline && 
                   currentTime < activeTextCharacters[i].appearanceTime + letterReveal_HighlightDuration) {
                    allNormal = false;
                    break;
                }
            }
            if(allNormal) break;

            yield return null; 
        }
        
        if(node != null && textBox != null) textBox.text = node.nodeText; 

        if (wordAudioSource != null && wordAudioSource.isPlaying)
        {
            wordAudioSource.Stop();
        }
        displayTextCoroutine = null; 
    }
}
