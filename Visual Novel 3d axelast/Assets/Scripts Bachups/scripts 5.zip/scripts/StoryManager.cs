using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StoryManager : MonoBehaviour
{
    public Image backgroundImage;
    public TextMeshProUGUI textBox;

    public StoryNode currentNode;

    public AudioClip sewingSoundClip; // Sound to play when space is held
    public AudioSource sewingAudioSource; // AudioSource for the sewing sound
    public AudioSource backgroundAudioSource; // AudioSource for node-specific background sounds
    public AudioSource wordAudioSource; // AudioSource for typing sound
    public AudioClip typingSoundClip; // Single sound to loop/play during text reveal

    [Header("Per-Letter Text Reveal Settings")]
    public float letterReveal_MinDelay = 0.02f;
    public float letterReveal_MaxDelay = 0.1f;
    public float letterReveal_HighlightDuration = 1.0f;
    public float letterReveal_SizeMultiplier = 1.2f; // e.g., 1.2 for 120%
    public Color letterReveal_HighlightColor = new Color(0.85f, 0.85f, 0.85f, 1f); // A light grey

    private Coroutine displayTextCoroutine; // To manage the text display coroutine
    private System.Collections.Generic.List<RevealedChar> activeTextCharacters;
    private System.Text.StringBuilder textBuilder = new System.Text.StringBuilder();
    private float baseFontSize; // To store the original font size of the textBox

    private bool isSewing = false; // True if space is currently held down
    private bool sewingSoundActiveForThisHold; // True if sound should be playing for current sewing action
    private Vector2 startPos; // Still used for initial press, but logic changes
    private Vector2 previousMousePosition; // For accumulating distance
    private float accumulatedSewingDistance; // Accumulates total path length
    public float requiredDistance = 500f;

    private struct RevealedChar
    {
        public char character;
        public float appearanceTime;
        public bool isVisible;
        public bool isSpaceOrNewline; // To handle spaces/newlines correctly without highlighting
    }

    void Awake()
    {
        // Setup Sewing AudioSource
        if (sewingAudioSource == null)
        {
            Debug.LogWarning("StoryManager: sewingAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            sewingAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure properties are set even if it was assigned in Inspector
        sewingAudioSource.loop = true;
        sewingAudioSource.playOnAwake = false;

        // Setup Background AudioSource
        if (backgroundAudioSource == null)
        {
            Debug.LogWarning("StoryManager: backgroundAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            backgroundAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure it's a different component if auto-added and sewingAudioSource was also auto-added
        if (backgroundAudioSource == sewingAudioSource && sewingAudioSource.gameObject.GetComponents<AudioSource>().Length < 2) {
             // This case implies both were null and AddComponent was called for sewingAudioSource.
             // If backgroundAudioSource points to the same one, we need a new one.
             Debug.LogWarning("StoryManager: backgroundAudioSource was pointing to the same component as sewingAudioSource. Adding a distinct AudioSource for background.");
             backgroundAudioSource = gameObject.AddComponent<AudioSource>();
        }
        backgroundAudioSource.loop = true;
        backgroundAudioSource.playOnAwake = false;

        // Setup Word AudioSource
        if (wordAudioSource == null)
        {
            Debug.LogWarning("StoryManager: wordAudioSource was not assigned in the Inspector. Adding a new AudioSource component for it.");
            wordAudioSource = gameObject.AddComponent<AudioSource>();
        }
        // Ensure it's a different component if auto-added
        if ((wordAudioSource == sewingAudioSource || wordAudioSource == backgroundAudioSource) && sewingAudioSource.gameObject.GetComponents<AudioSource>().Length < 3) {
            Debug.LogWarning("StoryManager: wordAudioSource was pointing to the same component as another AudioSource. Adding a distinct AudioSource for words.");
            wordAudioSource = gameObject.AddComponent<AudioSource>();
        }
        wordAudioSource.loop = true; // For typing sound loop
        wordAudioSource.playOnAwake = false;

        // Final check if any are still null (shouldn't happen with AddComponent)
        if (sewingAudioSource == null) Debug.LogError("CRITICAL: sewingAudioSource is STILL NULL after Awake setup!");
        if (backgroundAudioSource == null) Debug.LogError("CRITICAL: backgroundAudioSource is STILL NULL after Awake setup!");
        if (wordAudioSource == null) Debug.LogError("CRITICAL: wordAudioSource is STILL NULL after Awake setup!");

        if (textBox != null)
        {
            baseFontSize = textBox.fontSize;
        }
        else
        {
            Debug.LogError("StoryManager: textBox is not assigned in Awake. Base font size cannot be determined for letter animations.");
            // Potentially set a default baseFontSize or handle this more gracefully.
            baseFontSize = 36; // Default fallback if textBox is not set early
        }
    }

    void Start()
    {
        ShowNode(currentNode);
    }

    void Update()
    {
        // Handle sewing input and sound
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (sewingAudioSource == null)
            {
                Debug.LogError("StoryManager: sewingAudioSource is not assigned in the Inspector or couldn't be found/added in Awake().");
            }
            else if (sewingSoundClip == null)
            {
                Debug.LogError("StoryManager: sewingSoundClip is not assigned in the Inspector.");
            }
            // Sound starting logic moved to a helper or inline
            // No longer checking isPlaying here, as sewingSoundActiveForThisHold controls intent
            else
            {
                // Start playing sound only if it's intended for this new hold action
                if (sewingSoundActiveForThisHold && !sewingAudioSource.isPlaying)
                {
                    Debug.Log("StoryManager: Starting sewing sound.");
                    sewingAudioSource.clip = sewingSoundClip;
                    sewingAudioSource.Play();
                }
            }
            startPos = Input.mousePosition; 
            previousMousePosition = Input.mousePosition;
            // accumulatedSewingDistance is reset here
            isSewing = true; 
            sewingSoundActiveForThisHold = true; // Sound should play at the start of a new hold
            accumulatedSewingDistance = 0f; // Reset for the new sewing action
        }
        else if (Input.GetKeyUp(KeyCode.Space)) 
        {
            if (sewingAudioSource != null && sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Stopping sewing sound on space release.");
                sewingAudioSource.Stop();
            }
            isSewing = false;
            sewingSoundActiveForThisHold = false;
            accumulatedSewingDistance = 0f; // Reset accumulated distance when space is released
        }

        if (isSewing)
        {
            // If sound should be active but isn't playing (e.g., after a reset but space still held), start it.
            // This handles the case where distance is met, sound stops, counter resets, and user continues to hold space.
            if (sewingSoundActiveForThisHold && sewingAudioSource != null && sewingSoundClip != null && !sewingAudioSource.isPlaying)
            {
                Debug.Log("StoryManager: Restarting sewing sound during continuous hold.");
                sewingAudioSource.clip = sewingSoundClip;
                sewingAudioSource.Play();
            }
            
            Vector2 currentMousePosition = Input.mousePosition;
            float deltaDistance = (currentMousePosition - previousMousePosition).magnitude;
            accumulatedSewingDistance += deltaDistance;
            previousMousePosition = currentMousePosition;

            Debug.Log("Accumulated Sewing Distance: " + accumulatedSewingDistance);

            if (accumulatedSewingDistance >= requiredDistance)
            {
                Debug.Log("StoryManager: Required distance met.");
                Next("sew");
                
                if (sewingAudioSource != null && sewingAudioSource.isPlaying)
                {
                    Debug.Log("StoryManager: Stopping sewing sound because required distance met.");
                    sewingAudioSource.Stop();
                }
                sewingSoundActiveForThisHold = false; // Stop sound for the rest of this "segment"

                // Reset for next potential trigger in the same hold, sound will restart if user keeps moving.
                accumulatedSewingDistance = 0f; 
                // If space is still held, the next Update will set sewingSoundActiveForThisHold = true
                // if we want sound to restart for the *next* segment immediately.
                // As per new feedback, sound should NOT restart until space is released and pressed again.
                // So, sewingSoundActiveForThisHold remains false for the rest of this hold.
            }
        }
        else // if !isSewing (e.g. space was released, or sewing action completed)
        {
            // Ensure sound is stopped if isSewing became false for any reason other than KeyUp
            if (sewingAudioSource != null && sewingAudioSource.isPlaying && !sewingSoundActiveForThisHold) {
                sewingAudioSource.Stop();
            }
        }

        // Handle click input
        if (Input.GetMouseButtonDown(0))
        {
            Next("click");
        }
    }

    void ShowNode(StoryNode node)
    {
        if (node == null)
        {
            Debug.LogError("ShowNode: node is null. Make sure currentNode is assigned in the Inspector.");
            if (textBox != null)
            {
                textBox.text = "Error: Story node not found.";
            }
            return;
        }

        if (textBox == null)
        {
            Debug.LogError("ShowNode: textBox is null. Make sure the TextMeshProUGUI component is assigned in the Inspector.");
            return;
        }
        // Stop any existing text display coroutine and associated sound
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
        }
        
        InitializeTextForAnimation(node.nodeText); // Prepare characters for animation
        textBox.text = ""; // Clear text box before starting new text animation
        
        displayTextCoroutine = StartCoroutine(AnimateTextCharacterByCharacter(node));

        if (backgroundImage == null)
        {
            Debug.LogWarning("ShowNode: backgroundImage is null. Background will not be updated.");
        }
        else
        {
            backgroundImage.sprite = node.background;
        }

        // Handle node-specific background sound
        if (backgroundAudioSource != null)
        {
            if (backgroundAudioSource.isPlaying)
            {
                backgroundAudioSource.Stop();
            }
            if (node.backgroundSound != null)
            {
                backgroundAudioSource.clip = node.backgroundSound;
                backgroundAudioSource.Play();
            }
        }
        
        currentNode = node;
    }

    void Next(string method)
    {
        // It's good practice to stop text coroutine before moving to next node,
        // ShowNode already does this, so direct call here might be redundant
        // but ensures it if Next() logic changes.
        if (displayTextCoroutine != null)
        {
            StopCoroutine(displayTextCoroutine);
            if (wordAudioSource != null && wordAudioSource.isPlaying)
            {
                wordAudioSource.Stop();
            }
            displayTextCoroutine = null;
            // Ensure the full text of the current node is displayed instantly, without animation tags.
            if (currentNode != null && textBox != null) textBox.text = currentNode.nodeText;
        }

        if (method == "sew" && currentNode.nextOnSew != null)
            ShowNode(currentNode.nextOnSew);
        else if (method == "click" && currentNode.nextOnClick != null)
            ShowNode(currentNode.nextOnClick);
    }

    void InitializeTextForAnimation(string textToAnimate)
    {
        if (activeTextCharacters == null)
        {
            activeTextCharacters = new System.Collections.Generic.List<RevealedChar>();
        }
        activeTextCharacters.Clear();

        if (string.IsNullOrEmpty(textToAnimate)) return;

        foreach (char c in textToAnimate)
        {
            activeTextCharacters.Add(new RevealedChar
            {
                character = c,
                appearanceTime = float.MaxValue, // Not appeared yet
                isVisible = false,
                isSpaceOrNewline = (c == ' ' || c == '\n' || c == '\r')
            });
        }
    }

    void UpdateDisplayedText()
    {
        if (textBox == null || activeTextCharacters == null) return;
        if (baseFontSize <= 0 && textBox != null) baseFontSize = textBox.fontSize; // Attempt to get base font size again if missed in Awake

        textBuilder.Clear();
        float currentTime = Time.time;
        string highlightColorHex = ColorUtility.ToHtmlStringRGB(letterReveal_HighlightColor);
        // TMP uses font units for size tags, not percentages directly in the way CSS might.
        // <size=X> sets absolute font units. <size=+X> or <size=X%> are relative.
        // Let's use percentage for clarity with multiplier.
        string sizeTagStart = $"<size={letterReveal_SizeMultiplier * 100f}%>";
        const string sizeTagEnd = "</size>";
        string colorTagStart = $"<color=#{highlightColorHex}>";
        const string colorTagEnd = "</color>";

        for (int i = 0; i < activeTextCharacters.Count; i++)
        {
            RevealedChar charInfo = activeTextCharacters[i];
            if (!charInfo.isVisible)
            {
                // To maintain layout for partially revealed text, we might need to add invisible chars
                // or ensure TextMeshPro handles this well. For now, break if not visible.
                // A better way is to build up to the last visible char.
                break; 
            }

            if (charInfo.isSpaceOrNewline)
            {
                textBuilder.Append(charInfo.character);
            }
            else if (currentTime < charInfo.appearanceTime + letterReveal_HighlightDuration)
            {
                // Apply highlight
                textBuilder.Append(sizeTagStart);
                textBuilder.Append(colorTagStart);
                textBuilder.Append(charInfo.character);
                textBuilder.Append(colorTagEnd);
                textBuilder.Append(sizeTagEnd);
            }
            else
            {
                // Normal character
                textBuilder.Append(charInfo.character);
            }
        }
        textBox.text = textBuilder.ToString();
    }


    System.Collections.IEnumerator AnimateTextCharacterByCharacter(StoryNode node)
    {
        if (textBox == null)
        {
            Debug.LogError("AnimateTextCharacterByCharacter: textBox is null.");
            displayTextCoroutine = null;
            yield break;
        }
        
        if (activeTextCharacters == null || activeTextCharacters.Count == 0)
        {
             // This case means InitializeTextForAnimation wasn't called or node text was empty.
             // ShowNode should call InitializeTextForAnimation.
            if (node != null && !string.IsNullOrEmpty(node.nodeText)) InitializeTextForAnimation(node.nodeText);
            else {
                textBox.text = ""; // Ensure text is cleared
                if (wordAudioSource != null && wordAudioSource.isPlaying) wordAudioSource.Stop();
                displayTextCoroutine = null;
                yield break;
            }
        }

        if (wordAudioSource != null && typingSoundClip != null && !wordAudioSource.isPlaying)
        {
            wordAudioSource.clip = typingSoundClip;
            wordAudioSource.loop = true;
            wordAudioSource.Play();
        }

        // This loop reveals characters one by one
        for (int i = 0; i < activeTextCharacters.Count; i++)
        {
            RevealedChar charInfo = activeTextCharacters[i];
            charInfo.isVisible = true;
            charInfo.appearanceTime = Time.time;
            activeTextCharacters[i] = charInfo; // Update struct in list

            UpdateDisplayedText(); // Update the visible text box content

            if (!charInfo.isSpaceOrNewline) // Don't delay for spaces/newlines themselves, but content after them
            {
                 yield return new WaitForSeconds(Random.Range(letterReveal_MinDelay, letterReveal_MaxDelay));
            } else if (charInfo.character == '\n') { // Optional: slightly longer pause for newlines
                 yield return new WaitForSeconds(Random.Range(letterReveal_MinDelay, letterReveal_MaxDelay) * 2f);
            }
        }

        // This loop keeps updating the text for highlight fade-outs after all chars are visible
        float animationEndTime = Time.time + letterReveal_HighlightDuration; 
        while (Time.time < animationEndTime)
        {
            UpdateDisplayedText();
            // Check if all characters have returned to normal state to potentially end early
            bool allNormal = true;
            float currentTime = Time.time;
            for(int i=0; i < activeTextCharacters.Count; ++i) {
                if(activeTextCharacters[i].isVisible && !activeTextCharacters[i].isSpaceOrNewline && 
                   currentTime < activeTextCharacters[i].appearanceTime + letterReveal_HighlightDuration) {
                    allNormal = false;
                    break;
                }
            }
            if(allNormal) break;

            yield return null; // Wait for next frame
        }
        
        // Ensure final text is clean without tags if UpdateDisplayedText doesn't run one last time
        textBox.text = node.nodeText; 

        if (wordAudioSource != null && wordAudioSource.isPlaying)
        {
            wordAudioSource.Stop();
        }
        displayTextCoroutine = null; // Mark as finished
    }
}
