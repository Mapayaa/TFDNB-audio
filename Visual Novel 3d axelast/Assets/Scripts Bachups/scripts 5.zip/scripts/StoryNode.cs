using UnityEngine;

public class StoryNode : MonoBehaviour
{
    public string nodeText;
    public Sprite background;
    public AudioClip backgroundSound; // Added for node-specific background audio
    public StoryNode nextOnSew;
    public StoryNode nextOnClick;
}
