using UnityEngine;
using System.Collections.Generic; // Required for List<>

[System.Serializable]
public class ConditionalClickTransition
{
    [Tooltip("Optional description for Inspector clarity.")]
    public string description;
    [Tooltip("Number of clicks within the current chapter (specifically for Chapter 4 logic).")]
    public int requiredChapterClicks;
    public StoryNode targetNode;
}

// PenaltyClickTransition class is removed as it's now managed centrally in StoryManager

public class StoryNode : MonoBehaviour
{
    public enum NodeRole { User, Machine, Extra }

    [Tooltip("Welke rol is actief op deze node?")]
    public NodeRole nodeRole = NodeRole.User;

    [Tooltip("Moet een click op deze node meetellen voor de click/penalty teller?")]
    public bool meetellenAlsClick = true;
    [Tooltip("The chapter this node belongs to.")]
    public int chapter = 1;
    [TextArea(3, 10)]
    public string nodeText;
    public Sprite background;
    public AudioClip backgroundSound; 
    public StoryNode nextOnSew;
    public StoryNode nextOnClick;

    [Header("Chapter 4 Conditional Transitions")]
    [Tooltip("Transitions based on click count within Chapter 4.")]
    public List<ConditionalClickTransition> chapter4ClickTransitions;

    // penaltyClickTransitions list is removed
}
