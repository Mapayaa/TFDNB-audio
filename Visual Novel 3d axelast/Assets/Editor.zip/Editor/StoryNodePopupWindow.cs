using UnityEngine;
using UnityEditor;

public class StoryNodePopupWindow : EditorWindow
{
    private static StoryNodePopupWindow currentWindow;

    private StoryNode node;
    private SerializedObject nodeSO;
    private string originalJson;
    private bool changesMade = false;

    public static void ShowWindow(StoryNode node)
    {
        if (node == null) return;
        if (currentWindow != null)
        {
            currentWindow.Close();
        }
        var window = ScriptableObject.CreateInstance<StoryNodePopupWindow>();
        currentWindow = window;
        window.node = node;
        window.nodeSO = new SerializedObject(node);
        window.originalJson = JsonUtility.ToJson(node);
        window.titleContent = new GUIContent("StoryNode Details");
        window.position = new Rect(Screen.width / 2, Screen.height / 2, 400, 400);
        window.ShowUtility();
    }

    void OnGUI()
    {
        if (node == null || nodeSO == null)
        {
            EditorGUILayout.LabelField("Geen node geladen.");
            if (GUILayout.Button("OK")) this.Close();
            return;
        }

        nodeSO.Update();

        EditorGUILayout.LabelField("StoryNode Details", EditorStyles.boldLabel);
        EditorGUILayout.Space();

        EditorGUILayout.PropertyField(nodeSO.FindProperty("chapter"));
        EditorGUILayout.PropertyField(nodeSO.FindProperty("nodeText"));
        EditorGUILayout.PropertyField(nodeSO.FindProperty("background"));
        EditorGUILayout.PropertyField(nodeSO.FindProperty("meetellenAlsClick"));
        // EditorGUILayout.PropertyField(nodeSO.FindProperty("nextOnClick"));
        // EditorGUILayout.PropertyField(nodeSO.FindProperty("nextOnSew"));
        EditorGUILayout.PropertyField(nodeSO.FindProperty("backgroundSound"));
        EditorGUILayout.PropertyField(nodeSO.FindProperty("nodeRole"));

        // Nieuwe checkboxes voor StoryNode Details
        EditorGUILayout.PropertyField(nodeSO.FindProperty("disableClick"));
        EditorGUILayout.PropertyField(nodeSO.FindProperty("disableSew"));

        nodeSO.ApplyModifiedProperties();

        EditorGUILayout.Space();
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("OK"))
        {
            changesMade = true;
            this.Close();
        }
        if (GUILayout.Button("Cancel"))
        {
            // Revert changes
            if (!string.IsNullOrEmpty(originalJson))
                JsonUtility.FromJsonOverwrite(originalJson, node);
            this.Close();
        }
        EditorGUILayout.EndHorizontal();
    }

    void OnLostFocus()
    {
        if (!changesMade && !string.IsNullOrEmpty(originalJson) && node != null)
        {
            JsonUtility.FromJsonOverwrite(originalJson, node);
        }
    }

    void OnDestroy()
    {
        if (currentWindow == this)
            currentWindow = null;
    }
}
