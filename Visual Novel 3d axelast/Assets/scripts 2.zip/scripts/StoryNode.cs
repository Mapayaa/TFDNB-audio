using UnityEngine;
using System.Collections.Generic; // Required for List<>

public class StoryNode : MonoBehaviour
{
    public enum NodeRole { User, Machine, Extra }

    [Tooltip("Welke rol is actief op deze node?")]
    public NodeRole nodeRole = NodeRole.User;

    [Tooltip("Moet een click op deze node meetellen voor de click/penalty teller?")]
    public bool meetellenAlsClick = true;

    [Header("StoryNode Details")]
    [Tooltip("Als dit aan staat, is click op deze node uitgeschakeld.")]
    public bool disableClick = false;

    [Tooltip("Als dit aan staat, is sew op deze node uitgeschakeld.")]
    public bool disableSew = false;

    [Tooltip("The chapter this node belongs to.")]
    public int chapter = 1;
    [TextArea(3, 10)]
    public string nodeText;
    public Sprite background;
    public AudioClip backgroundSound; 
    public StoryNode nextOnSew;
    public StoryNode nextOnClick;

}
